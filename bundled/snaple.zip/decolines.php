<div class="decolines">
  <span class="decoline"></span>
  <span class="decoline"></span>
  <span class="decoline"></span>
  <span class="decoline"></span>
  <span class="decoline"></span>
  <span class="decoline"></span>
</div>